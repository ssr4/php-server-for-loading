INSERT INTO tablo_content.sp_sluzhba (code,naim) VALUES
	 (1,'В'),
	 (2,'ДМВ'),
	 (3,'П'),
	 (4,'НС'),
	 (5,'НТЭ'),
	 (6,'Т'),
	 (7,'ТР'),
	 (8,'Ш'),
	 (9,'Д'),
	 (10,'ДРП');
INSERT INTO tablo_content.sp_sluzhba (code,naim) VALUES
	 (11,'ДПО'),
	 (13,'СЗДОСС'),
	 (14,'СЗФПКФ'),
	 (15,'ДИ'),
	 (17,'ДПМ'),
	 (18,'ДТВ'),
	 (19,'ДМ'),
	 (20,'СО'),
	 (12,'ДЭЗ'),
	 (23,'ДМС');
INSERT INTO tablo_content.sp_sluzhba (code,naim) VALUES
	 (22,'РДЖВ'),
	 (21,'ДАВС');
