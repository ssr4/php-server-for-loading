INSERT INTO accounts.users (username,password_hash,created_at,"role") VALUES
	 ('feodor2@email','$2y$10$S.PPVZ7.DVzH2Mr34BWJ6OmZKQPYyrfU1vQU6NWmsST6zefN/mpp6','2025-03-18 16:10:30.749631','dms'),
	 ('feodor@2','$2y$10$459Ap..lkpKTL8WpiU7xBewI6sza04X9jSX7BKhX1qjmEPgtH9Ng.','2025-03-18 16:14:28.264126','dms'),
	 ('feodor@email','$2y$10$WFwb3AJXlDwWnb/BCt2Tu.W2hH26x2.wVOmIZZI7MygMoWMNW9tEy','2025-03-18 16:14:39.314579','dms'),
	 ('szdss_LevichevAA@orw.rzd','$2y$10$32jIdiFSTukPYEWstotVfuzH1pZdpjDaZzkXNCXKgRzwYjQRGyGJu','2025-03-20 14:11:28.18468','davs'),
	 ('di_SergeevaVV@orw.rzd','$2y$10$TM5pZqSxWl4pso38WxgrV.q8hf/7uRSJngicfEJBFGBSRhRKi51k.','2025-03-25 15:24:47.933','szdoss');
