INSERT INTO accounts.temp_users (username,password_hash,"role") VALUES
	 ('d_FedorovVP@orw.rzd','$2y$10$x.p4pAuGlpJQ9RPFX2/C.u3kKwJ9nQzl0k37wgOIVkxblv7nbhq/u','d'),
	 ('d_BelokopytovAV@orw.rzd','$2y$10$.4Ui3bx.tcXfAwdsJfM.PeVddj/UO4Yv1K0FqhoyYtmYBvfOQMJt.','d'),
	 ('d_ZimoninDA@orw.rzd','$2y$10$4hINDgLCv4rQX9skl0AMnuP5F.KnyybScWbDaktp7pGhZ8TEnrVW2','d'),
	 ('d_OlshevskiyAV@orw.rzd','$2y$10$B8vJeNNGvLZwqSwKRiIGAePe5.7TqPfsPSUfx7.FlY9mSSgv29d8q','d'),
	 ('d_ShulyakLM@orw.rzd','$2y$10$5XnVzI8.SQ040HEYoZV5ruvVrml5L1SJ4ZbXTk/OPQCUaGJd.0Moa','d'),
	 ('d_BryzgalovAA@orw.rzd','$2y$10$u2gtF0bg21rdPL.OKlcsQ.5YE5SkuZa92zPNyI0P0HnQdHYrxfxk6','d'),
	 ('d_AleshkinaNB@orw.rzd','$2y$10$jIJ53lfdegQAaQR05qsOJOpzlGwr2gj9I/PN5EDIyrM2/9SXXpR7O','d'),
	 ('dmv_EvplovVV@orw.rzd','$2y$10$3n6vmnaOAE8o9.LHS/gfLO6jjAlXjHmWUKVdUACa39kmyCweOXF1.','dmv'),
	 ('dmv_ShapovalovVV@orw.rzd','$2y$10$AaRkOasghlzrqkAnw0od5OlZLKpGp9OYzVMzIAk49aNcpytXYpElS','dmv'),
	 ('dpo_VasilevaNV@orw.rzd','$2y$10$fNBnIDpHK8qM7sz/e9QY1uUVso2rPso2NLS05zZz46JAI9fYQ/28a','dpo');
INSERT INTO accounts.temp_users (username,password_hash,"role") VALUES
	 ('ngch3_DzhafarovEH@orw.rzd','$2y$10$EkpceJK4rq.8n3dAsAszBehspiEaN7wzv2fyM8kz286kGNhxQZZ36','dez'),
	 ('dez_disp_centr@orw.rzd','$2y$10$HSVlmuJ2b9/hbTAUpHqEY.eShkrcefvJZbiYDwxakEUhKdNraJ.Na','dez'),
	 ('di_KirillovKI@orw.rzd','$2y$10$BWkiXLaugqHAwthiFyfxwus45co.u2CS5yxMI7iQGo3YwHP0y.ah6','di'),
	 ('nte_PoroshinaTA@orw.rzd','$2y$10$yww0e.sOB0f0HJRQxACvAuqPSk18TJZpiCqWj07ywTBfUJXJAra6u','nte'),
	 ('nte_BudantsevSV@orw.rzd','$2y$10$A51MVGDah9wFTx21FbxerukmbWjK/s0zTOqycHH.4fmkqD1csbQ7u','nte'),
	 ('nte_TelepkoPD@orw.rzd','$2y$10$j6om7FlJxhkkFKBA8HOGYOtkfcZKAMrE2zkp0G2kA4kPGtqer1amK','nte'),
	 ('davs_ShanbaevMA@orw.rzd','$2y$10$Z19HG0AAoAmSprd3ndGimOdOIpRP/oaqk4lNTFzOXn7/.ta61r0Z.','davs'),
	 ('rdzhv_AgronskayaON@orw.rzd','$2y$10$3V629/mnT/A5KkPfCCSHSeLsEe6KxpBbxaJHAnDkSjjIfU.2geRfy','rdzv'),
	 ('mch4_SergeevaVI@orw.rzd','$2y$10$a.KdVxXUtv4J2qMni6wnoe.t4j1QOfZMw0Z.hGTDD/HIGZQ4G7KFC','dm'),
	 ('d_LotohinMV@orw.rzd','$2y$10$YG21WIW0v6uy70GD/5nEC.hV25RHg9kyew8tnFzEWLI7RbACAYHH.','d');
INSERT INTO accounts.temp_users (username,password_hash,"role") VALUES
	 ('dmto_KulkovVV@orw.rzd','$2y$10$207tsEAsvJi9JcmTGFN.c.HixwGvBSr6CEarS6zgQh892ZUQpMzH6','dms'),
	 ('dt_NikonovAV@orw.rzd','$2y$10$I5U9VUCL0Tc7HeEDw27cOe8qxksNHQAZtvHyrAfvIm/UNBZvnTtHO','t');
