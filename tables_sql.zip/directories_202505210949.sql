INSERT INTO accounts.directories (sl_name,directory,regions,sl_code,order_description,allow_extensions) VALUES
	 ('РЦДМ','orders/rcdm',false,'rcdm','приказ ЦДИ','application/pdf'),
	 ('ЦУСИ','orders/cusi',false,'di','оперативный приказ','application/pdf'),
	 ('ДМВ','services/dmv',true,'dmv','','application/pdf'),
	 ('НТЭ','services/nte',true,'nte','','application/pdf'),
	 ('Т','services/t',true,'t','','application/pdf'),
	 ('Д','services/d',true,'d','','application/pdf'),
	 ('ДПО','services/dpo',true,'dpo','','application/pdf'),
	 ('СЗДОСС','services/szdoss',true,'szdoss','','application/pdf'),
	 ('ДМ','services/dm',true,'dm','','application/pdf'),
	 ('ДЭЗ','services/dez',true,'dez','','application/pdf');
INSERT INTO accounts.directories (sl_name,directory,regions,sl_code,order_description,allow_extensions) VALUES
	 ('ДМС','services/dms',true,'dms','','application/pdf'),
	 ('РДЖВ','services/rdzv',true,'rdzv','','application/pdf'),
	 ('ДИ','services/di',true,'di','','application/pdf'),
	 ('НС','services/ns',true,'ns','','application/pdf'),
	 ('Администратор','/',false,'admin','','application/pdf,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'),
	 ('ДАВС','services/davs',true,'davs','','application/pdf,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
