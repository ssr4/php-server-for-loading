INSERT INTO files_uploading.file_metadata (filename,upload_time,status,sent_at) VALUES
	 ('asdasdasd','2025-03-25 14:51:10.493782',NULL,NULL),
	 ('Динамическая модель загрузки инфраструктуры (20 03 2023).pdf','2025-04-07 11:07:49.264051','SENT',NULL),
	 ('Динамическая модель загрузки инфраструктуры (20 03 2023).pdf','2025-04-01 15:00:32.048303','SENT',NULL),
	 ('Динамическая модель загрузки инфраструктуры (20 03 2023).pdf','2025-04-01 15:09:51.715834','SENT',NULL),
	 ('pdf-forma-dlya-zapolneniya (1).pdf','2025-04-08 14:36:06.506','SENT',NULL),
	 ('pdf-forma-dlya-zapolneniya (1).pdf','2025-03-25 16:50:05.171051','SENT',NULL),
	 ('pdf-forma-dlya-zapolneniya (1).pdf','2025-04-01 09:36:43.379139','SENT',NULL),
	 ('pdf-forma-dlya-zapolneniya (1).pdf','2025-04-01 15:00:32.0627','SENT',NULL),
	 ('pdf-forma-dlya-zapolneniya (1).pdf','2025-04-01 15:09:51.731372','SENT',NULL),
	 ('pdf-forma-dlya-zapolneniya (1).pdf','2025-04-07 11:07:49.283766','SENT',NULL);
INSERT INTO files_uploading.file_metadata (filename,upload_time,status,sent_at) VALUES
	 ('pdf-forma-dlya-zapolneniya (1).pdf','2025-04-17 09:19:09.291506','UPLOADED',NULL),
	 ('Динамическая модель загрузки инфраструктуры (20 03 2023).pdf','2025-04-17 10:04:18.853713','UPLOADED',NULL),
	 ('Динамическая модель загрузки инфраструктуры (20 03 2023).pdf','2025-04-17 14:34:32.402539','UPLOADED',NULL),
	 ('pdf-forma-dlya-zapolneniya (1).pdf','2025-04-17 14:34:32.411543','UPLOADED',NULL),
	 ('Динамическая модель загрузки инфраструктуры (20 03 2023).pdf','2025-04-17 14:35:11.941324','UPLOADED',NULL),
	 ('pdf-forma-dlya-zapolneniya (1).pdf','2025-04-17 14:35:11.950467','UPLOADED',NULL);
